package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.State;
import com.example.demo.repository.StateRepository;
import com.example.demo.service.StateService;





@RequestMapping(value = "/State")
@RestController
public class StateController {
	
	@Autowired
	StateService stateService;
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public State createState(@RequestParam State state)
	{
		State returnState= stateService.createState(state);
		return returnState;
	}
	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public Optional<State> readState(@RequestParam int stateId)
	{
		Optional<State> returnState= stateService.readState(stateId);
		return returnState;
		
	}
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String createState(@RequestParam State state, @RequestParam int stateId)
	{
		String returnStatus="";
		boolean chk = stateService.checkIfExists(stateId);
		if(chk)
		{
			State returnState= stateService.createState(state);
			if(returnState != null)
				returnStatus= "Updated";
		}
		else 
			returnStatus= "No record for the given id";
		return returnStatus;
	}
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public void deleteState(@RequestParam int stateId)
	{
		stateService.deleteState(stateId);
	}

}

