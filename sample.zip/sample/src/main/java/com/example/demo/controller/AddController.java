package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.AddressType;
import com.example.demo.repository.AddressTypeRepository;
import com.example.demo.service.AddService;

@RequestMapping(value = "/Add")
@RestController
public class AddController {
	
	@Autowired
	AddService addService;
	
	/*
	 * Request needs to be of POST type 
	 * Also, the JSON object is required to be passed in the request body
	 * The JSON will be like {"code": "HOME_ADD", "name": "Home Address"}
	 * */
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public AddressType createAddressType(@RequestBody AddressType addressType)
	{
		AddressType returnAddressType= addService.createAddressType(addressType);
		return returnAddressType;
	}
	
	/*
	 * Request needs to be of GET type 
	 * Input is required to be passed in the request parameter
	 * Input will be key value pair, where key is addressTypeId
	 * */
	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public Optional<AddressType> readAddressType(@RequestParam int addressTypeId)
	{
		Optional<AddressType> returnAddressType= addService.readAddressType(addressTypeId);
		return returnAddressType;
		
	}
	
	/*
	 * Request needs to be of POST type 
	 * Input is required to be passed in the request parameter as well as body
	 * Input will be key value pair, where key is addressTypeId in the parameter
	 * and JSON will be like {"id": 10, "code": "HOME_ADD", "name": "Home Address"}
	 * */
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String createAddressType(@RequestBody AddressType addressType, @RequestParam int addressTypeId)
	{
		String returnStatus="";
		boolean chk = addService.checkIfExists(addressTypeId);
		if(chk)
		{
			AddressType returnAddressType= addService.createAddressType(addressType);
			if(returnAddressType != null)
				returnStatus = "Updated";
		}
		else 
			returnStatus = "No record for the given id";
		return returnStatus;
	}
	//No input is required, just a GET request needs to be made
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public void deleteAddressType(@RequestParam int addressTypeId)
	{
		addService.deleteAdd(addressTypeId);
	}

}


