package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.AddService;
import com.example.demo.service.CityService;
import com.example.demo.service.StateService;

@RequestMapping(value = "/Master")
@RestController
public class MasterController {
	@Autowired
	AddService addService;
	@Autowired
	StateService stateService;
	@Autowired
	CityService cityService;
	
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public List<Page> readAdd()
	{
		List<Page> addTypeTable = addService.master();
		
		return addTypeTable;
		
	}
	@RequestMapping(value = "/state", method = RequestMethod.GET)
	public List<Page> readState()
	{
		List<Page> stateTable = stateService.master();
		
		return stateTable;
		
	}
	@RequestMapping(value = "/city", method = RequestMethod.GET)
	public List<Page> readCity()
	{
		List<Page> cityTable = cityService.master();
		
		return cityTable;
		
	}
	

}
