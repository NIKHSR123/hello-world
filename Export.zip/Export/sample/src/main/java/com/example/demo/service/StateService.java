package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.entity.State;
import com.example.demo.repository.StateRepository;



@Service
public class StateService {
	@Autowired
	StateRepository stateRepository;
	
	public State createState(State state) {
		return stateRepository.save(state);
	}
	public Optional<State> readState(int stateId)
	{
		
		return stateRepository.findById(stateId);
	}
	
	public boolean checkIfExists(int stateId)
	{
		return stateRepository.existsById(stateId);
	}
	
	public void deleteState(int stateId) {
		stateRepository.deleteById(stateId);
		
	}
	public List<Page> master(){
		long pageSize= stateRepository.count(); 
		List<Page> responsestateList = null;
		int psize=(int) pageSize;
		for(int i=0; i< psize; psize++)
		responsestateList.add(stateRepository.findAll(PageRequest.of(i, 1)));
		return responsestateList;
	}

}
