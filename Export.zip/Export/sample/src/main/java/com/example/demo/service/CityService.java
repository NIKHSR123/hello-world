package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.entity.City;
import com.example.demo.repository.CityRepository;



@Service
public class CityService {
	@Autowired
	CityRepository cityRepository;
	
	public City createCity(City city) {
		return cityRepository.save(city);
	}
	public Optional<City> readCity(int cityId)
	{
		
		return cityRepository.findById(cityId);
	}
	
	public boolean checkIfExists(int cityId)
	{
		return cityRepository.existsById(cityId);
	}
	
	public void deleteCity(int cityId) {
		cityRepository.deleteById(cityId);
		
	}
	public List<Page> master(){
		long pageSize= cityRepository.count(); 
		List<Page> responsecityList = null;
		int psize=(int) pageSize;
		for(int i=0; i< psize; psize++)
		responsecityList.add(cityRepository.findAll(PageRequest.of(i, 1)));
		return responsecityList;
	}

}
