package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.City;
import com.example.demo.service.CityService;





@RequestMapping(value = "/City")
@RestController
public class CityController {
	
	@Autowired
	CityService cityService;
	/*
	 * Request needs to be of POST type 
	 * Also, the JSON object is required to be passed in the request body
	 * The JSON will be like {"name": "Jalandhar", "stateId": 10}
	 * */
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public City createCity(@RequestBody City city)
	{
		City returnCity= cityService.createCity(city);
		return returnCity;
	}
	/*
	 * Request needs to be of GET type 
	 * Input is required to be passed in the request parameter
	 * Input will be key value pair, where key is cityId
	 * */
	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public Optional<City> readCity(@RequestParam int cityId)
	{
		Optional<City> returnCity= cityService.readCity(cityId);
		return returnCity;
		
	}
	
	/*
	 * Request needs to be of POST type 
	 * Input is required to be passed in the request parameter as well as body
	 * Input will be key value pair, where key is cityId in the parameter
	 * and JSON will be like {"id": 10, "name": "Jalandhar", "stateId": 10}
	 * */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String createCity(@RequestBody City city, @RequestParam int cityId)
	{
		String returnStatus="";
		boolean chk = cityService.checkIfExists(cityId);
		if(chk)
		{
			City returnCity= cityService.createCity(city);
			if(returnCity != null)
				returnStatus= "Updated";
		}
		else 
			returnStatus= "No record for the given id";
		return returnStatus;
	}
	
	//No input is required, just a GET request needs to be made
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public void deleteCity(@RequestParam int cityId)
	{
		cityService.deleteCity(cityId);
	}

}

