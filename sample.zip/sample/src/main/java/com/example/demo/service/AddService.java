package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.AddressType;
import com.example.demo.repository.AddressTypeRepository;

@Service
public class AddService {
	@Autowired
	AddressTypeRepository addressTypeRepository;
	
	public AddressType createAddressType(AddressType addressType) {
		return addressTypeRepository.save(addressType);
	}
	public Optional<AddressType> readAddressType(int addressTypeId)
	{
		
		return addressTypeRepository.findById(addressTypeId);
	}
	
	public boolean checkIfExists(int addressTypeId)
	{
		return addressTypeRepository.existsById(addressTypeId);
	}
	
	public void deleteAdd(int addressTypeId) {
		addressTypeRepository.deleteById(addressTypeId);
		
	}
	public List<Page> master(){
		long pageSize= addressTypeRepository.count(); 
		List<Page> responseaddressTypeList = null;
		int psize=(int) pageSize;
		for(int i=0; i< psize; psize++)
		responseaddressTypeList.add(addressTypeRepository.findAll(PageRequest.of(i, 1)));
		return responseaddressTypeList;
	}

}
