package com.example.demo.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.example.demo.entity.AddressType;

public interface AddressTypeRepository extends PagingAndSortingRepository<AddressType, Integer>{

}
