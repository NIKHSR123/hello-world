package com.example.demo.repository;

import org.springframework.data.repository.PagingAndSortingRepository;


import com.example.demo.entity.State;

public interface StateRepository extends PagingAndSortingRepository<State, Integer>{


}
