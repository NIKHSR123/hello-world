package com.example.demo.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.example.demo.entity.City;

public interface CityRepository extends PagingAndSortingRepository<City, Integer>{


}
