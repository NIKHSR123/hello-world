package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.AddressType;
import com.example.demo.repository.AddressTypeRepository;
import com.example.demo.service.AddService;

@RequestMapping(value = "/Add")
@RestController
public class AddController {
	
	@Autowired
	AddService addService;
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public AddressType createAddressType(@RequestParam AddressType addressType)
	{
		AddressType returnAddressType= addService.createAddressType(addressType);
		return returnAddressType;
	}
	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public Optional<AddressType> readAddressType(@RequestParam int addressTypeId)
	{
		Optional<AddressType> returnAddressType= addService.readAddressType(addressTypeId);
		return returnAddressType;
		
	}
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String createAddressType(@RequestParam AddressType addressType, @RequestParam int addressTypeId)
	{
		String returnStatus="";
		boolean chk = addService.checkIfExists(addressTypeId);
		if(chk)
		{
			AddressType returnAddressType= addService.createAddressType(addressType);
			if(returnAddressType != null)
				returnStatus = "Updated";
		}
		else 
			returnStatus = "No record for the given id";
		return returnStatus;
	}
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public void deleteAddressType(@RequestParam int addressTypeId)
	{
		addService.deleteAdd(addressTypeId);
	}

}


